# SmartCloudFS (low-latency core)
Open this folder in Android Studio (Koala+), let it sync (it generates the Gradle wrapper), Run.

## One-time Google setup
1. Google Cloud Console -> new project -> enable **Google Drive API**.
2. OAuth consent screen -> add scope `drive.readonly` (add yourself as a test user).
3. Credentials -> OAuth client ID -> **Android**, package `com.smartcloudfs`, your debug SHA-1
   (`./gradlew signingReport`).

## How it stays fast
- Reads go through `openProxyFileDescriptor`: callers get a seekable fd, only needed 2 MB blocks are fetched (HTTP Range).
- Disk block cache, keyed by file id + md5/modified time; LRU eviction; atomic writes; deduped concurrent fetches.
- One-block read-ahead on a bounded pool; pooled HTTP/2 connections; 60 s listing cache; exp. backoff on 429/5xx.

## Limits
- Read-only. Games needing a real filesystem path cannot run from this; materialize files locally for those.
- `drive.readonly` is a restricted scope: fine for personal/test use, public release needs Google verification.
- Not yet built: Room index, pinning, adaptive controller, Gaming Mode, benchmark screen (Stages 4-7).
- Not compiled here (no Android SDK in my sandbox): expect to fix small errors on first sync.

## Build without a PC (phone only)
1. Create a GitHub repo, upload all files (keep the `.github` folder). Actions builds automatically.
2. Repo -> Actions -> latest run -> download artifact **SmartCloudFS-apk**, unzip, install the APK.
3. For OAuth use the SHA-1 of the bundled key `app/scfs.jks` (fixed, so it never changes between builds).
