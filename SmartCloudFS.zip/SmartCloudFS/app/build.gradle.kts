plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.smartcloudfs"
    compileSdk = 34
    defaultConfig { applicationId = "com.smartcloudfs"; minSdk = 29; targetSdk = 34; versionCode = 1; versionName = "0.1" }
    signingConfigs { getByName("debug") { storeFile = file("scfs.jks"); storePassword = "scfs1234"; keyAlias = "scfs"; keyPassword = "scfs1234" } }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
