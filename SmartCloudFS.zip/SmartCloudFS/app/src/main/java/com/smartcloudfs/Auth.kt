package com.smartcloudfs

import android.content.Context
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import java.io.IOException

/** OAuth via Google Identity Services. No passwords, no self-managed refresh tokens. */
object Auth {
    private val request = AuthorizationRequest.builder()
        .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.readonly"))).build()
    @Volatile private var token: String? = null
    @Volatile private var expiresAt = 0L

    fun request() = request
    fun client(ctx: Context) = Identity.getAuthorizationClient(ctx)

    fun accept(r: AuthorizationResult) { token = r.accessToken; expiresAt = System.currentTimeMillis() + 50 * 60_000 }
    fun invalidate() { token = null }

    /** Blocking: call from a background/binder thread only. */
    fun token(ctx: Context): String {
        token?.let { if (System.currentTimeMillis() < expiresAt) return it }
        val r = Tasks.await(client(ctx).authorize(request))
        if (r.hasResolution() || r.accessToken == null) throw IOException("Open SmartCloudFS and sign in")
        accept(r); return r.accessToken!!
    }
}
