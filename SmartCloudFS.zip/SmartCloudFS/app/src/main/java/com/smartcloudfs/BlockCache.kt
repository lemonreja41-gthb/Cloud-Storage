package com.smartcloudfs

import android.content.Context
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Disk block cache: 2 MB blocks, one file per block, atomic tmp+rename.
 * Keyed by fileId+version, so a changed cloud file never serves stale blocks.
 * Concurrent requests for the same block share one download. Sequential reads trigger read-ahead.
 */
class BlockCache(ctx: Context, private val drive: DriveClient, var maxBytes: Long = 1L shl 30) {
    companion object { const val BLOCK = 2 * 1024 * 1024 }
    private val root = File(ctx.cacheDir, "blocks").apply { mkdirs() }
    private val locks = ConcurrentHashMap<String, Any>()
    private val ahead = Executors.newFixedThreadPool(2)   // bounded concurrency
    @Volatile var hits = 0L; @Volatile var misses = 0L

    private fun blockFile(it: Item, n: Long) = File(File(root, it.id + "_" + it.version.take(12)).apply { mkdirs() }, "$n.blk")

    private fun block(item: Item, n: Long): File {
        val f = blockFile(item, n)
        if (f.exists()) { hits++; f.setLastModified(System.currentTimeMillis()); return f }
        synchronized(locks.getOrPut(f.path) { Any() }) {
            if (f.exists()) { hits++; return f }
            misses++
            val start = n * BLOCK
            val end = minOf(start + BLOCK, item.size) - 1
            val data = drive.range(item.id, start, end)
            val tmp = File(f.path + ".tmp")
            tmp.outputStream().use { it.write(data) }
            if (!tmp.renameTo(f)) throw IOException("rename failed")
        }
        locks.remove(f.path); evictIfNeeded(protect = f)
        return f
    }

    fun read(item: Item, offset: Long, size: Int, out: ByteArray): Int {
        if (offset >= item.size) return 0
        var pos = offset; var done = 0
        val limit = minOf(offset + size, item.size)
        while (pos < limit) {
            val n = pos / BLOCK; val inBlock = (pos % BLOCK).toInt()
            val f = block(item, n)
            val take = minOf((limit - pos).toInt(), (f.length() - inBlock).toInt())
            if (take <= 0) break
            java.io.RandomAccessFile(f, "r").use { it.seek(inBlock.toLong()); it.readFully(out, done, take) }
            pos += take; done += take
        }
        val next = pos / BLOCK + 1
        if (next * BLOCK < item.size && !blockFile(item, next).exists())
            ahead.execute { runCatching { block(item, next) } }   // read-ahead of one block
        return done
    }

    fun usedBytes() = root.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    /** LRU by last-access time. Deletes only local blocks, never cloud files. */
    @Synchronized private fun evictIfNeeded(protect: File) {
        var used = usedBytes(); if (used <= maxBytes) return
        root.walkTopDown().filter { it.isFile && it != protect }.sortedBy { it.lastModified() }.forEach {
            if (used <= maxBytes) return
            val l = it.length(); if (it.delete()) used -= l
        }
    }
}
