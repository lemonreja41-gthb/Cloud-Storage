package com.smartcloudfs

import android.content.Context
import android.util.LruCache
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.time.Instant
import java.util.concurrent.TimeUnit

data class Item(val id: String, val name: String, val mime: String, val size: Long, val modified: Long, val md5: String?) {
    val isDir get() = mime == FOLDER
    /** Changes whenever content changes, so stale cached blocks are never served. */
    val version get() = md5 ?: modified.toString()
    companion object { const val FOLDER = "application/vnd.google-apps.folder" }
}

class DriveClient(private val ctx: Context) {
    private val http = OkHttpClient.Builder()
        .connectionPool(ConnectionPool(4, 5, TimeUnit.MINUTES)) // keep TLS/HTTP2 warm = low latency
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val base = "https://www.googleapis.com/drive/v3/files"
    private val fields = "id,name,mimeType,size,modifiedTime,md5Checksum"

    private class Listing(val at: Long, val items: List<Item>)
    private val listings = LruCache<String, Listing>(64)
    private val metas = LruCache<String, Item>(2048)

    private fun call(url: String, range: String? = null): Response {
        var delay = 300L
        repeat(5) { attempt ->
            val b = Request.Builder().url(url).header("Authorization", "Bearer " + Auth.token(ctx))
            if (range != null) b.header("Range", range)
            val r = try { http.newCall(b.build()).execute() } catch (e: IOException) { if (attempt == 4) throw e; null }
            if (r != null) {
                if (r.isSuccessful) return r
                val code = r.code; r.close()
                if (code == 401) Auth.invalidate()
                else if (code != 429 && code !in 500..599 && code != 403) throw IOException("HTTP $code")
                if (attempt == 4) throw IOException("HTTP $code")
            }
            Thread.sleep(delay); delay *= 2
        }
        throw IOException("unreachable")
    }

    private fun parse(o: JSONObject) = Item(
        o.getString("id"), o.getString("name"), o.getString("mimeType"),
        o.optString("size", "0").toLong(),
        runCatching { Instant.parse(o.getString("modifiedTime")).toEpochMilli() }.getOrDefault(0),
        o.optString("md5Checksum").ifEmpty { null })

    fun get(id: String): Item {
        metas.get(id)?.let { return it }
        val s = call("$base/$id?fields=$fields&supportsAllDrives=true").use { it.body!!.string() }
        return parse(JSONObject(s)).also { metas.put(id, it) }
    }

    fun list(parent: String): List<Item> {
        listings.get(parent)?.let { if (System.currentTimeMillis() - it.at < 60_000) return it.items }
        val out = ArrayList<Item>(); var page: String? = null
        do {
            val q = java.net.URLEncoder.encode("'$parent' in parents and trashed=false", "UTF-8")
            var url = "$base?q=$q&pageSize=1000&fields=nextPageToken,files($fields)&supportsAllDrives=true&includeItemsFromAllDrives=true"
            if (page != null) url += "&pageToken=$page"
            val j = JSONObject(call(url).use { it.body!!.string() })
            val a = j.getJSONArray("files")
            for (i in 0 until a.length()) {
                val it = parse(a.getJSONObject(i))
                if (it.isDir || !it.mime.startsWith("application/vnd.google-apps")) { out.add(it); metas.put(it.id, it) }
            }
            page = j.optString("nextPageToken").ifEmpty { null }
        } while (page != null)
        listings.put(parent, Listing(System.currentTimeMillis(), out)); return out
    }

    /** Range read, inclusive end. Only the requested bytes cross the network. */
    fun range(id: String, start: Long, endInclusive: Long): ByteArray =
        call("$base/$id?alt=media&supportsAllDrives=true", "bytes=$start-$endInclusive").use { it.body!!.bytes() }
}
