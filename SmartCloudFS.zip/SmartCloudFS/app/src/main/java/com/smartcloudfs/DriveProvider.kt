package com.smartcloudfs

import android.database.Cursor
import android.database.MatrixCursor
import android.os.*
import android.os.storage.StorageManager
import android.provider.DocumentsContract.Document
import android.provider.DocumentsContract.Root
import android.provider.DocumentsProvider
import android.system.ErrnoException
import android.system.OsConstants
import android.webkit.MimeTypeMap

class DriveProvider : DocumentsProvider() {
    private val drive by lazy { DriveClient(context!!) }
    private val cache by lazy { BlockCache(context!!, drive) }
    private val rootCols = arrayOf(Root.COLUMN_ROOT_ID, Root.COLUMN_FLAGS, Root.COLUMN_TITLE, Root.COLUMN_DOCUMENT_ID, Root.COLUMN_SUMMARY)
    private val docCols = arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE,
        Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED, Document.COLUMN_FLAGS)

    override fun onCreate() = true

    override fun queryRoots(projection: Array<out String>?): Cursor = MatrixCursor(projection ?: rootCols).apply {
        newRow().add(Root.COLUMN_ROOT_ID, "drive").add(Root.COLUMN_FLAGS, Root.FLAG_SUPPORTS_IS_CHILD)
            .add(Root.COLUMN_TITLE, "SmartCloudFS").add(Root.COLUMN_DOCUMENT_ID, "root").add(Root.COLUMN_SUMMARY, "Google Drive (cached)")
    }

    private fun MatrixCursor.add(i: Item) {
        val name = i.name
        val mime = if (i.isDir) Document.MIME_TYPE_DIR else
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
        newRow().add(Document.COLUMN_DOCUMENT_ID, i.id).add(Document.COLUMN_DISPLAY_NAME, name).add(Document.COLUMN_MIME_TYPE, mime)
            .add(Document.COLUMN_SIZE, i.size).add(Document.COLUMN_LAST_MODIFIED, i.modified).add(Document.COLUMN_FLAGS, 0)
    }

    override fun queryDocument(documentId: String, projection: Array<out String>?): Cursor = MatrixCursor(projection ?: docCols).apply {
        if (documentId == "root") newRow().add(Document.COLUMN_DOCUMENT_ID, "root").add(Document.COLUMN_DISPLAY_NAME, "Drive")
            .add(Document.COLUMN_MIME_TYPE, Document.MIME_TYPE_DIR).add(Document.COLUMN_FLAGS, 0)
        else add(drive.get(documentId))
    }

    override fun queryChildDocuments(parentDocumentId: String, projection: Array<out String>?, sortOrder: String?): Cursor =
        MatrixCursor(projection ?: docCols).apply { drive.list(parentDocumentId).forEach { add(it) } }

    override fun isChildDocument(parentDocumentId: String, documentId: String) = true

    override fun openDocument(documentId: String, mode: String, signal: CancellationSignal?): ParcelFileDescriptor {
        if (mode != "r") throw SecurityException("read-only provider")
        val item = drive.get(documentId)
        val thread = HandlerThread("scfs-" + item.id.take(6)).apply { start() }  // one reader thread per open file
        val cb = object : ProxyFileDescriptorCallback() {
            override fun onGetSize() = item.size
            override fun onRead(offset: Long, size: Int, data: ByteArray): Int = try {
                cache.read(item, offset, size, data)
            } catch (e: Exception) { throw ErrnoException("onRead", OsConstants.EIO) }
            override fun onRelease() { thread.quitSafely() }
        }
        val sm = context!!.getSystemService(StorageManager::class.java)
        return sm.openProxyFileDescriptor(ParcelFileDescriptor.MODE_READ_ONLY, cb, Handler(thread.looper))
    }
}
