package com.smartcloudfs

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable fun Screen() {
        var status by remember { mutableStateOf("Not signed in") }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
            runCatching { Auth.accept(Auth.client(this).getAuthorizationResultFromIntent(it.data)); status = "Signed in" }
                .onFailure { status = "Sign-in failed: ${it.message}" }
        }
        Column(Modifier.fillMaxSize().padding(24.dp).systemBarsPadding(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("SmartCloudFS", style = MaterialTheme.typography.headlineMedium)
            Text(status)
            Button(onClick = {
                Auth.client(this@MainActivity).authorize(Auth.request()).addOnSuccessListener { r ->
                    if (r.hasResolution()) launcher.launch(IntentSenderRequest.Builder(r.pendingIntent!!.intentSender).build())
                    else { Auth.accept(r); status = "Signed in" }
                }.addOnFailureListener { status = "Error: ${it.message}" }
            }) { Text("Sign in to Google Drive") }
            Text("Then open any SAF-aware app (Files, emulator, launcher) and pick \"SmartCloudFS\" as a storage source.")
        }
    }
}
